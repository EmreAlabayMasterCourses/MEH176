
#include <hls_video.h>
#include <hls_opencv.h>
#include "rgb2gray_header.h"

#define in_path "C:\\Users\\KuanTekEA\\Downloads\\img.jpg"
#define out_path "C:\\Users\\KuanTekEA\\Downloads\\img_out.jpg"


int main () {

	using namespace std;

	AXI_STREAM_OUT_TPG src_axi;
	AXI_STREAM_OUT dst_axi;
	cv::Mat src1,dst1;
	src1 = cv::imread(in_path,2);
	dst1 = src1;

	#pragma HLS dataflow

	TPG_8_BIT_RGB(src_axi);
	RGB2GRAY(src_axi,dst_axi);

    AXIvideo2cvMat(dst_axi, dst1);

    cv::imwrite(out_path,dst1);
	return 0;
}








