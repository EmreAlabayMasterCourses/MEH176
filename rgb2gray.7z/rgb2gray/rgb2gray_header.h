#include <hls_video.h>
#include "ap_int.h"

#define WIDTH       1280
#define HEIGHT      720

#define data_size       8
#define stream_in_width       24
#define stream_out_width       24

typedef ap_axiu<stream_in_width,1,1,1> interface_in;
typedef hls::stream<interface_in>      AXI_STREAM_IN;

typedef ap_axiu<stream_out_width,1,1,1> interface_out;
typedef hls::stream<interface_out>      AXI_STREAM_OUT;


void RGB2GRAY(AXI_STREAM_IN& INPUT_STREAM,AXI_STREAM_OUT& OUTPUT_STREAM,bool button);


typedef ap_axiu<stream_in_width,1,1,1> interface_out_tpg;
typedef hls::stream<interface_out_tpg>      AXI_STREAM_OUT_TPG;
void TPG_8_BIT_RGB(AXI_STREAM_OUT_TPG& OUTPUT_STREAM);
