#include "rgb2gray_header.h"

void RGB2GRAY(AXI_STREAM_IN& INPUT_STREAM,AXI_STREAM_OUT& OUTPUT_STREAM,bool button){

#pragma HLS INTERFACE axis port = INPUT_STREAM
#pragma HLS INTERFACE axis port = OUTPUT_STREAM

	interface_in input;
	interface_out output;

	ap_uint<24> data_out;
	ap_uint<24> data_in;

	int R;
	int B;
	int G;
	int GRAY;

	for_row: for (int i = 0; i < HEIGHT; i++){
			for_col: for (int j = 0; j < WIDTH; j++){

#pragma HLS pipeline II=1

				input=INPUT_STREAM.read();
				R=input.data.range(23,16);
				B=input.data.range(15,8);
				G=input.data.range(7,0);

				GRAY= ( 76*R + 150*G + 29*B ) >> 8;
				if(GRAY>255)
					GRAY=255;
				if(GRAY<0)
					GRAY=0;

				if(button){
					output.data.range(23,16)=GRAY;
					output.data.range(15,8)=GRAY;
					output.data.range(7,0)=GRAY;
				}
				else{
					output.data.range(23,16)=R;
					output.data.range(15,8)=B;
					output.data.range(7,0)=G;
				}

				  // Write output value
				if ((i==0) && (j==0))
					output.user = 1;
				else
					output.user = 0;
				if (j==(WIDTH-1))
					output.last = 1;
				else
					output.last = 0;
					output.keep=7;
					output.strb=7;


				OUTPUT_STREAM.write(output);

			}
	}

}

void TPG_8_BIT_RGB(AXI_STREAM_OUT_TPG& OUTPUT_STREAM){

#pragma HLS interface axis port = OUTPUT_STREAM

	interface_out_tpg output;
	ap_uint<stream_in_width> pixel_out;

	for( int row=0; row<HEIGHT; row++){
		for( int col=0; col<WIDTH; col++){

		#pragma HLS pipeline II=1
			//TPG
		      // Write output value
		      if ((row==0) && (col==0)){
		    	  output.user = 1;
		      }
		      else
		    	  output.user = 0;
		      if (col==(WIDTH-1))
		    	  output.last = 1;
		      else
		    	  output.last = 0;

		      //Solid RED Y=76 U=85 V=255
		      	  if(col<960){
				  //pixel_out.range(31,24)=21;
		      		  pixel_out.range(23,16)=255;
				  	  pixel_out.range(15,8)=50;
				  	  pixel_out.range(7,0)=150;
		      	  }
		      	  else{
		      		  pixel_out.range(23,16)=180;
				  	  pixel_out.range(15,8)=70;
				  	  pixel_out.range(7,0)=20;
		      	  }


		      output.keep=7;
		      output.strb=7;
		      output.data=pixel_out;

			OUTPUT_STREAM.write(output);



		}
	}

}
